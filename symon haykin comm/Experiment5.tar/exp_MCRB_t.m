%used in Experiment 5, CS: Haykin
% MCRB for Symbo Timing Recovery

BLT=.02;
for st=1:11
SNRdB =[0 5   10  15  20  25 30 35 40 45 50]; 
snr = 10^(SNRdB(st)/10);
CR(st)=1*BLT*(1/(4*pi^2*snr*0.1));
end