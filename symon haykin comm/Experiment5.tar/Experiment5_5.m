% Experiment 5, CS BOOK, Haykin
% Digital phase lock loop
% Track error  of the recursive Costas Loop. 
% Effect of varying signal-to-noise-ratio
% on convergence behaviour of the recursive Costas Loop
% Tested for SNR =5 10 30 dB for test size parameter =0.1  .



%angle shift

theta=pi/3;

%step size  =0.1

gamma=0.1;

% Generating QPSK signals

no_of_bits=400;

b=round(rand(no_of_bits,1));

bits=2*b-1;

bitsi=bits(1:2:length(bits)-1);

bitsq=bits(2:2:length(bits));

s_n=(bitsi+i*bitsq)/sqrt(2);



% signal to noise ratios 5, 10, 30 dB

 SNRdB =[5 10 30];


for snrdb=1:length(SNRdB)

snr = 10^(SNRdB(snrdb)/10);

% Add AWGN with STD equal to std_value
       
wn = (randn(length(s_n),1)+i*randn(length(s_n),1))/sqrt(2)/sqrt(snr);
        
s=s_n+wn;

         
% Digital Phase lock loop
            
no_of_symbols=length(s);
            
x=s*exp(i*theta);
            
theta_guess=0;  % initial guess
            
theta_hat=zeros(no_of_symbols,1);
            
theta_hat(1)=theta_guess;

           
%Recursive Costas Loop
                 
    for kk=1:no_of_symbols
                            
          y(kk)=x(kk)*exp(-i*theta_hat(kk));
                    
          s_predi(kk)=(sign(real(y(kk)))+...
          i*sign(imag(y(kk))))/sqrt(2);         

          error(kk)=imag(conj(s_predi(kk))*y(kk));
                          
          theta_hat(kk+1)= theta_hat(kk)+gamma*error(kk);
                
    end %kk

theta_hatf(:,snrdb)=theta_hat;


end %snrdb

%prints

figure(1);

plot(theta_hatf)

xlabel('Normalized time, t/T')

ylabel('Estimated phase (rad)')




