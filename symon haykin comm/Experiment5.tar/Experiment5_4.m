% Experiment 5
% Digital phase lock loop
% Track error  of the recursive Costas Loop. 
% Effect of varying the step size parameter 
% on convergence behaviour of the recursive Costas Loop
% Tested for test size parameter =0.1 and 0.5 for SNR =30 dB.



%angle shift
theta=pi/3;



% Generating QPSK signals

no_of_bits=400;

b=round(rand(no_of_bits,1));

bits=2*b-1;

bitsi=bits(1:2:length(bits)-1);

bitsq=bits(2:2:length(bits));

s_n=(bitsi+i*bitsq)/sqrt(2);


% signal to noise ratios 

 SNRdB =[30];  snr = 10^(SNRdB/10);

% Add AWGN with STD equal to std_value
 
wn = (randn(length(s_n),1)+i*randn(length(s_n),1))/sqrt(2)/sqrt(snr);

s=s_n+wn;


% Digital Phase lock loop
            
no_of_symbols=length(s);
         
x=s*exp(i*theta);

%step size  =0.1, 0.5

gamma_s=[0.1 0.5]; 

for step=1:length(gamma)

gamma=gamma_s(step);
            
theta_guess=0;  % initial guess
            
theta_hat=zeros(no_of_symbols,1);
            
theta_hat(1)=theta_guess;

         
%Recursive Costas Loop
                 
   for kk=1:no_of_symbols
                          
        y(kk)=x(kk)*exp(-i*theta_hat(kk));
    
        s_predi(kk)=(sign(real(y(kk)))+...
          i*sign(imag(y(kk))))/sqrt(2);

        error(kk)=imag(conj(s_predi(kk))*y(kk));
        
        theta_hat(kk+1)= theta_hat(kk)+gamma*error(kk);
               
   end %kk 

theta_hatf(:,step)=theta_hat;

end %step


%prints

figure(1);

plot(theta_hatf)

xlabel('Normalized time, t/T')

ylabel('Estimated phase (rad)')




