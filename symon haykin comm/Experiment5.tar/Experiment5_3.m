% Experiment 5, CSBOOK: haykin
% digital phase lock loop, S-curve
% With noise


clear all

% phase shift

theta=-0.1;

% Generating QPSK signals

no_of_bits=400; 

b=round(rand(no_of_bits,1));

bits=2*b-1;

bitsi=bits(1:2:length(bits)-1);

bitsq=bits(2:2:length(bits));

s=(bitsi+i*bitsq);


% Signal-to-noise-ratio 

SNRdB=20; snr = 10^(SNRdB/10);

% Initialize S_curve

S_curvef=0;

for trial=1:100

%Noise
 
wn = (randn(length(s),1)+ i*randn(length(s),1) )/sqrt(snr);
  
s=s+wn;

% Digital Phase lock loop
 
 no_of_symbols=length(s);
 
 x=s*exp(i*theta);
 
 k=0;

% accumulate S-curve

  for theta_guess= -pi:0.1:pi;
 
     k=k+1;

        phi(k)=theta-theta_guess;

        y=x*exp(-i*theta_guess);

       s_predi=(sign(real(y))+i*sign(imag(y)));

       error=imag(y.*conj(s_predi));

       S_curve(k)=mean(error);

  end% theta_guess
 


S_curvef=S_curvef+S_curve;

end % trial

S_curvef=S_curvef/trial;


% plot the S-curve

plot(phi,S_curvef)

xlabel('\phi')

ylabel('S(\phi)')






















