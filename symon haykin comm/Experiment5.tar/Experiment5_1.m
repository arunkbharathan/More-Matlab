%  Experiment 5
%  Digital phase lock loop
%  Track error variance of the recursive Costas Loop. 
%  Measured and Theory (MCRB)



%angle shift
theta=pi/3;

%step size 
A=1.06; BLT=0.02; gamma=4*BLT/(1+2*BLT)/A;

% Generating QPSK signals

no_of_bits=400;

b=round(rand(no_of_bits,1));

bits=2*b-1;

bitsi=bits(1:2:length(bits)-1);

bitsq=bits(2:2:length(bits));

s_n=(bitsi+i*bitsq)/sqrt(2);


% signal to noise ratios 
SNRdB =[5 10 15  20 25 30];

% Initialize variance
var1=0;

%Measured variance
% number of trials 1000

 for trial=1:1000

     for st=1:length(SNRdB)

          snr = 10^(SNRdB(st)/10);

         % Add AWGN with STD equal to std_value

          wn = (randn(length(s_n),1)+i*randn(length(s_n),1))/sqrt(2)/sqrt(snr);

          s=s_n+wn;

         % Digital Phase lock loop

            no_of_symbols=length(s);

            x=s*exp(i*theta); % Shift data

            theta_guess=0;  % initial guess

            theta_hat=zeros(no_of_symbols,1);

             theta_hat(1)=theta_guess;


                         for kk=1:no_of_symbols

                              y(kk)=x(kk)*exp(-i*theta_hat(kk));

                              s_predi(kk)=(sign(real(y(kk)))+...
                                          i*sign(imag(y(kk))))/sqrt(2);

                              error(kk)=imag(conj(s_predi(kk))*y(kk));

                              theta_hat(kk+1)= theta_hat(kk)+gamma*error(kk);

                         end %kk

                 var(st)=(std(theta_hat(50:200)))^2;

           end %st

var1=var1+var;

end %trial

var1=var1/trial;


% Theory (Modified)

for st=1:length(SNRdB)

  snr = 10^(SNRdB(st)/10);

  CR(st)=BLT/snr/sqrt(2);

end


%prints and labels

figure(1);

semilogy(SNRdB,CR,'--');

hold on;

semilogy(SNRdB,var1(1:length(var1)),'-o');

xlabel('E_s/N_0, dB')

ylabel('Phase error variance')




