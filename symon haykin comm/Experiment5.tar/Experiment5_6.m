% Experiment 5, CSBOOK: Haykin
% Timing (clock) recovery
% Measured S-curve of the 
% NDA-ELD loop, No-noise


clear all

% time slot

T=1/8000;deltaT=T/50;

%Nyquest pulse

t=[-3*T/2+deltaT/2:deltaT:3*T/2-deltaT/2];

h=sinc(2*t./T).*(cos(pi*t./T)./(1-2*t./T).^2);

% Generating QPSK signals

no_of_bits=2000;

b=round(rand(no_of_bits,1));

bits=2*b-1;

bitsi=bits(1:2:length(bits)-1);

bitsq=bits(2:2:length(bits));

amp=(bitsi+i*bitsq)/sqrt(2);

amp=conj(amp');

%FIR filtering

s_i=upfirdn(real(amp),h,50,1);

s_q=upfirdn(imag(amp),h,50,1);

s=s_i+i*s_q;

x=s(1: length(s)-15);

% FIR filtering

y_i=upfirdn(real(x),h,50,1);

y_q=upfirdn(imag(x),h,50,1);

y=(y_i+y_q);


%Timong error prediction

tau=15;

tauerror=-50:50;

tauhat=tau-tauerror;

for k=1:990

     tp(k,:)=y(75+50*k+48+tauhat)-y(75+50*k+3+tauhat);

     tq(k,:)=y(75+50*k+25+tauhat);

     tqconj(k,:)=conj(tq(k,:));

     e(k,:)=real(tqconj(k,:).*tp(k,:));

end

%Accumulate S_curve

for k=1:length(tauerror)

  S_curve(k)=mean(e(:,k));

end

% plots
plot(-0.48:1/50:0.5, S_curve(51:100))

ylabel('S-curve')

xlabel('Normalized timing offset, \delta/T')

