%Experiment 5, CSBOOK: haykin
% digital phase lock loop, S-curve
% No noise


clear all

% phase shift
theta=-0.1;


% Generating QPSK signals

no_of_bits=400;

b=round(rand(no_of_bits,1));

bits=2*b-1;

bitsi=bits(1:2:length(bits)-1);

bitsq=bits(2:2:length(bits));

s=(bitsi+i*bitsq)/sqrt(2);


% Digital Phase lock loop

no_of_symbols=length(s);

x=s*exp(i*theta);

k=0;


% accumulate S-curve

    for theta_guess= -pi:0.1:pi;

            k=k+1;
      
            phi(k)=theta-theta_guess;
      
            y=x*exp(-i*theta_guess);
      
            s_predi=(sign(real(y))+i*sign(imag(y)))/sqrt(2);

            error=imag(y.*conj(s_predi));

            S_curve(k)=mean(error);

     end % theta_guess
 

% plots and labels

plot(phi,S_curve)

xlabel('\phi')

ylabel('S(\phi)')






















