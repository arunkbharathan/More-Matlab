function output = turbo_encoder( Data, code_g, Alpha)
% Turbo encoder
% Used in Experiment 7, CS: Haykin


[n,K] = size(code_g); 

m = K - 1;

block_s = length(Data); 
 
y=zeros(3,block_s+m);


% encorder 1
%----------------------------------
state = zeros(m,1);

for i = 1: block_s+m

   if  i <= block_s

      d = Data(1,i);

   elseif  i >  block_s

      d = rem( code_g(1,2:K)*state, 2 );

   end

a = rem( code_g(1,:)*[d ;state], 2 );

v = code_g(2,1)*a;

   for j = 2:K

      v = xor(v, code_g(2,j)*state(j-1));

   end;

state = [a;state(1:m-1)];

y(1,i)=d;

y(2,i)=v;

end

%encorder 2
%-------------------------

% interleaving the data

for i = 1: block_s+m

   ytilde(1,i) = y(1,Alpha(i)); 

end


state = zeros(m,1);

for i = 1: block_s+m

     d = ytilde(1,i);
  
  a = rem( code_g(1,:)*[d ;state], 2 );

  v = code_g(2,1)*a;
 
      for j = 2:K

            v = xor(v, code_g(2,j)*state(j-1));

      end; %j

  state = [a; state(1:m-1)];

  y(3,i)=v;

end %i

% inserting data, odd parity and even parity
 
for i=1: block_s+m
  
     output(1,n*i-1) = 2*y(1,i)-1;
 
       if rem(i,2)
 
         output(1,n*i) = 2*y(2,i)-1;

       else

          output(1,n*i) = 2*y(3,i)-1;

       end %if 

end %i






