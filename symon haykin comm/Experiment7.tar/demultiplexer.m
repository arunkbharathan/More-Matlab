function output = demultiplexer(Data, Alpha);
% demultiplexing the received signal
% used in Experiment 7,  Communications system 4e: Simon Haykin



block_s = fix(length(Data)/2);

output=zeros(2,block_s);

for i = 1: block_s

       Dataf(i) = Data(2*i-1);

        if rem(i,2)>0

             output(1,2*i) = Data(2*i);

       else

          output(2,2*i) = Data(2*i);

       end      

     

end


for i = 1: block_s

      output(1,2*i-1) = Dataf(i);

      output(2,2*i-1) = Dataf(Alpha(i));

end