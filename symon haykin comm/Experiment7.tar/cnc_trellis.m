function [nxt_o, nxt_s, lst_o, lst_s] = cnc_trellis(code_g);
% used in Experiment 7, 
% Communications system 4e: Simon Haykin
% code trellis for  RSC




% code properties
[n,K] = size(code_g);
m = K - 1;
no_of_states = 2^m;

for s=1: no_of_states

dec_cnt_s=s-1; i=1;

% decimal to binary state
while  dec_cnt_s >=0 & i<=m
       bin_cnt_s(i) = rem( dec_cnt_s,2) ;
       dec_cnt_s  = (dec_cnt_s-  bin_cnt_s(i))/2;
        i=i+1;   
end
bin_cnt_s=bin_cnt_s(m:-1:1);
   
% next state when input is 0
   d = 0;
   a = rem( code_g(1,:)*[0 bin_cnt_s ]', 2 );
   v = code_g(2,1)*a;

   for j = 1:K-1
      v = xor(v, code_g(2,j+1)*bin_cnt_s(j));
   end;

nstate0 = [a  bin_cnt_s(1:m-1)];
y_0 = [0 v];


% next state when input is 1
   d = 1;
   a = rem( code_g(1,:)*[1 bin_cnt_s]', 2 );
   v = code_g(2,1)*a;

   for j = 1:K-1
      v = xor(v, code_g(2,j+1)*bin_cnt_s(j));
   end;

nstate1 = [a bin_cnt_s(1:m-1)];
y_1=[1 v];

% next output when input 0 1
nxt_o(s,:) = [y_0 y_1];

% binary to decimal state
d=2.^(m-1:-1:0); 
dstate0=nstate0*d'+1; dstate1=nstate1*d'+1;

% next state when input 0 1
nxt_s(s,:) = [ dstate0  dstate1 ];

% finding the possible previous state frm the trellis
lst_s(nxt_s(s, 1), 1)=s;
lst_s(nxt_s(s, 2), 2)=s;
lst_o(nxt_s(s, 1), 1:4) =  nxt_o(s, 1:4) ;
lst_o(nxt_s(s, 2), 1:4) =  nxt_o(s, 1:4) ;

end







