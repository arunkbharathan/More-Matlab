% Experiment 7, CS: Haykin
% Turbo Decoding


clear all

% Block size

block_size = 1000; 

% Convolutional code polynomial

code_polynomial = [ 1 1 1; 1 0 1 ];

[n,K]=size(code_polynomial); m=K-1;

% Code rate for  punctured code

code_rate = 1/2; 
   
% Number of iterations

no_of_iterations = 10;

% Number of blocks in error for termination 

block_error_limit = 15;

% signal-to-noise-ratio in db

SNRdb = [1 2 3 4]; 


for snrdb=1:length(SNRdb)

	snr = 10^(SNRdb(snrdb)/10);      

	fprintf('Signal-to-Noise-ratio = %d\n',SNRdb(snrdb))

%  channel reliability value and variance of AWGN channel 

	channel_reliability_value = 4*snr*code_rate;   

	noise_var = 1/(2*code_rate*snr);   

%initializing the error counters

	block_number = 0;  

	block_errors(1,1:no_of_iterations) = zeros(1, no_of_iterations);

	bit_errors(1,1:no_of_iterations) = zeros(1, no_of_iterations);

	total_errors=0;


   while block_errors(1,  no_of_iterations)< block_error_limit 
   
	block_number=block_number+1;

% Transmitter end
%------------------------------------
% generating random data

   	 Data = round(rand(1, block_size-m));   

% random scrambler
	
  	 [dummy, Alpha] = sort(rand(1,block_size));      

% turbo-encoder output

    	 turbo_encoded = turbo_encoder( Data, code_polynomial, Alpha) ; 

% Receiver end
%--------------------------------------------------
% AWGN+turbo-encoder out put

    	 received_signal = turbo_encoded+sqrt(noise_var)*randn(1,(block_size)*2); 

% demultiplexing the signals

    	demul_output = demultiplexer(received_signal, Alpha ); 

%scaled received signal

    	Datar=  demul_output *channel_reliability_value/2;

% Turbo decoder
%-----------------------------------------------------

	extrinsic = zeros(1, block_size);

	apriori = zeros(1, block_size);

    for  iteration = 1: no_of_iterations

% First decoder 

  	  apriori(Alpha) = extrinsic; 

   	 LLR = BCJL1(Datar(1,:), code_polynomial, apriori); 

   	 extrinsic = LLR - 2*Datar(1,1:2:2*(block_size)) - apriori; 

% Second decoder 

  	 apriori = extrinsic(Alpha);

  	 LLR = BCJL2(Datar(2,:), code_polynomial, apriori); 

  	 extrinsic = LLR - 2*Datar(2,1:2:2*(block_size)) - apriori; 

% Hard decision of information bits

   	 Datahat(Alpha) = (sign(LLR)+1)/2;

% Number of bit errors 

         bit_errors(iteration) = length(find(Datahat(1:block_size-m)~=Data));

% Number of block errors

        if bit_errors(iteration )>0

            block_errors(iteration) = block_errors(iteration) +1;

        end  %if 

    end   %iterations


%Total bit errors

	total_errors=total_errors+ bit_errors;

% bit error rate 
           
      if block_errors(no_of_iterations)==block_error_limit

          BER(snrdb,1:no_of_iterations)= total_errors(1:no_of_iterations)/...
                      block_number/(block_size-m);

      end %if 

 end  %while        

end %snrdb

% prints

semilogy(BER) 

xlabel('Number of iterations')

ylabel('BER')








