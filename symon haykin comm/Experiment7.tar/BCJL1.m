function L = BCJL1(Datar, code_g ,apriori)
% log-BCJL (LOG-MAP algorithm) for decoder 1
% Used in Experiment 1, CS: Haykin

% states, memory, constraint length and block size

block_s = fix(length(Datar)/2);

[n,K] = size(code_g); 

m = K - 1;

no_of_states = 2^m;     

infty = 1e10;

zero=1e-300;


% forward recursion

alpha(1,1) = 0; 

alpha(1,2:no_of_states) = -infty*ones(1,no_of_states-1);

% code-trellis

[nxt_o, nxt_s, lst_o, lst_s] = cnc_trellis(code_g);

nxt_o = 2*nxt_o-1;

lst_o = 2*lst_o-1;

for i = 1:block_s

    for cnt_s = 1:no_of_states

      branch = -infty*ones(1,no_of_states);

      branch(lst_s(cnt_s,1)) = -Datar(2*i-1)+Datar(2*i)*...
             lst_o(cnt_s,2)-log(1+exp(apriori(i)));
 
     branch(lst_s(cnt_s,2)) = Datar(2*i-1)+Datar(2*i)*...
      lst_o(cnt_s,4)+apriori(i)-log(1+exp(apriori(i)));
    
       if(sum(exp(branch+alpha(i,:)))>zero)

              alpha(i+1,cnt_s) = log( sum( exp( branch+alpha(i,:))));  

        else alpha(i+1,cnt_s) =-1*infty;

       end   
 end

    alpha_max(i+1) = max(alpha(i+1,:));
    
   alpha(i+1,:) = alpha(i+1,:) - alpha_max(i+1);

end     

% backward recursion

beta(block_s,1)=0;

beta(block_s,2:no_of_states) = -infty*ones(1,no_of_states-1); 


for i = block_s-1:-1:1

  for cnt_s = 1:no_of_states

     branch = -infty*ones(1,no_of_states);

     branch(nxt_s(cnt_s,1)) = -Datar(2*i+1)+Datar(2*i+2)*...
     nxt_o(cnt_s,2)-log(1+exp(apriori(i+1)));

     branch(nxt_s(cnt_s,2)) = Datar(2*i+1)+Datar(2*i+2)*...
     nxt_o(cnt_s,4)+apriori(i+1)-log(1+exp(apriori(i+1)));

     if(sum(exp(branch+beta(i+1,:)))>zero)

 	 beta(i,cnt_s) = log(sum(exp(branch+beta(i+1,:))));
       

     else

       beta(i,cnt_s)=-infty;

    end   

  end

beta(i,:) = beta(i,:) - alpha_max(i+1);

end

for k = 1:block_s

  for cnt_s = 1:no_of_states

     branch0 = -Datar(2*k-1)+Datar(2*k)*lst_o(cnt_s,2)-log(1+exp(apriori(k)));

     branch1 = Datar(2*k-1)+Datar(2*k)*lst_o(cnt_s,4)+apriori(k)-...
           log(1+exp(apriori(k)));

     den(cnt_s) = exp( alpha(k,lst_s(cnt_s,1))+branch0+  beta(k,cnt_s));

     num(cnt_s) = exp( alpha(k,lst_s(cnt_s,2))+branch1+ beta(k,cnt_s));

  end

L(k) = log(sum(num)) - log(sum(den));

end





