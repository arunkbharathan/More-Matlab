function uprim =lin(t,u)
% used in Experiment 2, Communications system 4e: Simon Haykin
% PLL 
% Transfer function (1+a/s), 
% gain K=50 rad/s
% sinusoidal modulation: fm=50/2/pi/sqrt(2pi)
% damping 0.707


uprim(1)=u(2);

uprim(2)=-cos(u(1))*u(2)-0.5*sin(u(1))-(1/2/pi)*sin(50*t/sqrt(2*pi));

uprim=uprim';