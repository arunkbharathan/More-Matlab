% Experiment 2, CS: Haykin
% phase lock loop and cycle slipping
% requires functions lin.m  to run
% Experiment2_2.m and Experiment2_1.m are used for Part 3 
% of Experiment2.

% time interval

t0=0;tf=25;

% frequency step =0.1 Hz

delf=0.1;
u0=[0 -delf*2*pi];
[t,u]=ode23('lin',[t0 tf],u0); plot(t,u(:,2)/2/pi+delf);
xlabel('Time (s)')
ylabel('f_i (t), (Hz)')
hold on

% frequency step = 0.2 Hz

delf=0.2;
u0=[0 -delf*pi*2]';                                  
[t,u]=ode23('lin',[t0 tf],u0); plot(t,u(:,2)/2/pi+delf);
xlabel('Time (s)');
ylabel('f_i (t), (Hz)');


% frequency step =0.3 Hz

delf=0.3;
u0=[0 -delf*pi*2]';                                  
[t,u]=ode23('lin',[t0 tf],u0); plot(t,u(:,2)/2/pi+delf);
xlabel('Time (s)');
ylabel('f_i (t), (Hz)');


% frequency step =0.4 Hz

delf=4; 
u0=[0 -delf*pi*2]';                                  
[t,u]=ode23('lin',[t0 tf],u0); plot(t,u(:,2)/2/pi+delf);
xlabel('Time (s)');
ylabel('f_i (t), (Hz)');





