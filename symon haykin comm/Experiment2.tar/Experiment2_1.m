% Experiment 2, CSBOOK-Haykin
% Communications systems 4e: Simon  Haykin 
% Phase lock loop simulator
% phase portrait of phase error Vs Frequency error
% program lin.m is used for integration.




t0=0;tf=20; % time

hold off; clf; Va=[-2 10 -5 5];axis(Va),

hold on;grid on

%contours

u0=[10 -0.5];                                   
 [t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -1.4];                                   
 [t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -1];
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -2];    
 [t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -2.5];  
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -3];                                     
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -3.5];   
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[10 -4];
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))


u0=[-2 5.0];    
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 4.5];  
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 4];
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 3.5];
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 3.2];  
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 3.0];    
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

 u0=[-2 2.5];   
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 2];  
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

u0=[-2 1];  
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2))

% Limits

tf=7;u0=[10 -1.5];                                   
 [t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2),'LineWidth',2)

tf=5;u0=[10 -1.3];                                   
 [t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2),'LineWidth',2)

tf=20; u0=[pi, -0.1];   
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2),'LineWidth',2)

 u0=[pi, 0.01]; 
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2),'LineWidth',2)

tf=5;u0=[-2 2.845]; 
[t,u]=ode45('lin',[t0 tf],u0); plot(u(:,1),u(:,2),'LineWidth',2)


xlabel('Phase error')
ylabel('Frequency error')
