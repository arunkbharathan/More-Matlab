% Experiment 2, CSBOOK-Haykin
% phase lock loop
% Variation of the phase error for 
% three different values of damping factor (xi) 

% Damping factor

xi=[0.3 0.707 1];

% Phase error

for kk=1:length(xi)

	num=[2*xi(kk)-1 1];

	den=[1 2*xi(kk) 1];

	[u1,u2,u3,u4]=tf2ss(num,den);

	dt=0.01;

	a=ones(1,2000);

	b=zeros(2,2001);

		for i=1:2000

			b(:,i+1)=b(:,i)+dt*u1*b(:,i)+dt.*u2*a(i);

        		c(i)=u3*b(:,i);

		end %i

	t=[0:dt:20];

	plot(t,b(1,:))

  	hold on
end %kk

xlabel('time (s)')

ylabel('Phase error (rad)')
