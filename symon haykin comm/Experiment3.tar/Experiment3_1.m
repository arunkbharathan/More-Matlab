%Experiment 3, CSBOOK: Haykin
% function to generate Linear Delta Modulation for sinwave

% generating sinwave
  
t=[0:2*pi/100:2*pi];       

a=10*sin(t);  
  
 n=length(a);
  
dels=1;
  
xhat(1:n)=0;
  
x(1:n)=a;
  
d(1:n)=0;

%  Linear Delta Modulation

 for k=1: n

	if (x(k)-xhat(k)) > 0

  		d(k)=1;

	else d(k)=-1;

	end %if

   xtilde(k)=xhat(k)+d(k)*dels;

   xhat(k+1)=xtilde(k);

 end %k

%Prints

 figure(1); hold on;

 plot(a)

 plot(xhat);

 plot(d-15);

 axis([0 100 -20 20])