%Experiment 3, CSBOOK-Haykin
% adaptive delta modulation for sinwave

% Generating sin wave

t=[0:2*pi/100:2*pi];       

a=10*sin(t);  

n=length(a);

mindels=1;

dels(1:n)=mindels;

xhat(1:n)=0;

x(1:n)=a;

% Adaptive  Delta Modulation

d(1:n)=1;

for k=2:n

 	
	if ((x(k)-xhat(k-1)) > 0 )
    	
		d(k)=1;
 	
	else d(k)=-1;

	end %if

	if k==2
		xhat(k)=d(k)*mindels+xhat(k-1);
	end

	if ((xhat(k)-xhat(k-1)) > 0)

	    if (d(k-1)  == -1 &d(k) ==1)

		xhat(k+1)=xhat(k)+0.5*(xhat(k)-xhat(k-1));
	   
	    elseif (d(k-1)  == 1 &d(k) ==1)

		xhat(k+1)=xhat(k)+1.15*(xhat(k)-xhat(k-1));

	    elseif (d(k-1)  == 1 &d(k) ==-1)

		xhat(k+1)=xhat(k)-0.5*(xhat(k)-xhat(k-1));

	    elseif (d(k-1)  == -1 &d(k) ==-1)
  
		xhat(k+1)=xhat(k)-1.15*(xhat(k)-xhat(k-1));

	    end
	else

	   if (d(k-1)  == -1 &d(k) ==1)

		xhat(k+1)=xhat(k)-0.5*(xhat(k)-xhat(k-1));

	  elseif (d(k-1)  == 1 &d(k) ==1)

		xhat(k+1)=xhat(k)-1.15*(xhat(k)-xhat(k-1));

	  elseif (d(k-1)  == 1 &d(k) ==-1)

		xhat(k+1)=xhat(k)+0.5*(xhat(k)-xhat(k-1));

	  elseif (d(k-1)  == -1 &d(k) ==-1)

	 	xhat(k+1)=xhat(k)+1.15*(xhat(k)-xhat(k-1));

          end

	end
end


%Plots

figure(1);hold on;

plot(a);

plot(xhat);

plot(d-15)