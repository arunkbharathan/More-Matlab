% Experiment 4, CS: Haykin
% Eyediagram
% baseband PAM transmission, M=2
% The channel has bandwidth limitations
% channel is modeled as low pass butterworth filter 
% Nyquist bandwidth 0.5Hz, \alpha=0.5 
% Requires Comm Toolbox to run.

clear all

% Define the M-ary number, calculation sample frequency 
M=4; Fs=20;

% Define the number of points in the calculation
Pd=50;

% The default symbol rate is Fd=1
% Generate an integer message in range [0, M-1].
msg_d = exp_randint(Pd,1,M);

% Use square constellation PAM method for modulation
msg_a = exp_modmap(msg_d,Fs,M);

% Assume the channel equivalent to a raised cosine filter.

[B,A]=butter(25,0.85);
rb_a =filter(B,A,msg_a);
rcv_a = rcosflt(rb_a,1,Fs,'Fs');

% plot the eye pattern diagram of the received signal
eyescat(rcv_a,0.5,Fs)
axis([0.5 2.5 -1.5 1.5])
