function y = exp_modmap(x, Fs,M);
% PAM modulation
% Used in Experiment 4


x=x-(M-1)/2;

x=2*x/(M-1);

y=zeros(length(x)*Fs,1);

p=0;

for k=1:Fs:length(y)

       p=p+1;
  
       y(k:(k+Fs-1))=x(p)*ones(Fs,1);

end