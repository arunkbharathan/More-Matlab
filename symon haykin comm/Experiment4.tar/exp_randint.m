function out = exp_randint(p, q, r);
% random interger generator
% used in Experiment 4


r = [0, r-1];

r = sort(r);

r(1) = ceil(r(1));

r(2) = floor(r(2));

if r(1) == r(2) 

    out = ones(p, q) * r(1);

    return;

end;

d = r(2) - r(1);

r1 = rand(p, q);

out = ones(p,q)*r(1);

for i = 1:d

    index = find(r1 >= i/(d+1));

    out(index) = (r(1) + i) * index./index;

end;