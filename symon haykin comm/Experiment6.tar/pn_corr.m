function [corrf]=pn_corr(u, v, N)
% funtion to compute the autocorreation/ cross-correlation
%  function of two PN sequences
% used in Experiment 6, CS: Haykin 


max_cross_corr=0;

for m=0:N

     shifted_u=[u(m+1:N) u(1:m)];
   
     corr(m+1)=(sum(v.*shifted_u));

		if (abs(corr)>max_cross_corr)

		      max_cross_corr=abs(corr);

		end

end

corr1=flipud(corr);

corrf=[corr1(2:N) corr];

