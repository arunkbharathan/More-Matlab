function x =  PNseq(p)
% Linear shift register for generating PN  sequence of polynomial p 
% used in Experiment 6 
%  Communications system 4e: Simon Haykin

 
N = length(p) - 1; % order of the polynomial

p = fliplr(p);

X = [1 zeros(1, N-1)];

n = 1;

for i = 1 : n*(2^N - 1)

  x(i) = X(1);

  X = [X(2:N) p(N+1) * rem(sum(p(1:N) .* X(1:N)), 2)];

end
