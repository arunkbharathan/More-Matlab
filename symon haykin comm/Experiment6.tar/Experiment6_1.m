% Experiment 6, CS: Haykin
% Generating 127-chip PN sequences
% polynomial1(x)  = x^7 + x+1
% polynomial2(x) = x^7+x^6 + x^5 + x^4 + 1
% Autocorrelation and cross correlation functions
% requires functions pn_corr.m, PNseq.m, shift_register.m to run

% polynomials

pol1=[1 0 0  1 0 0 0 1];

pol2=[1 1 1 1  0 0 0 1];

% chip size

N=127;

% generating the PN sequence

pnseq1 = PNseq(pol1);

pnseq2 = PNseq(pol2);

% mapping  antipodal signals (0-->-1,  1-->1)

u=2*pnseq1-1;

v=2*pnseq2-1;

% autocorrelation of pnseq1

[corrf]=pn_corr(u, u, N);

% prints

figure(1)

plot(-125:126,corrf(2:253)); axis([-126, 126,-10, 150])

xlabel(' Delay \tau')

ylabel(' Autocorrelation function R_{c}(\tau)')

%autocorrelation of pnseq2

[corrf]=pn_corr(v, v, N)

% prints

figure(2)

plot(-125:126,corrf(2:253)); axis([-126, 126,-10, 150])

xlabel(' Delay \tau')

ylabel(' Autocorrelation function R_{c}(\tau)')

% cross correlation of pnseq1, pnseq2

[c_corr]=pn_corr(u, v, N)

% prints

figure(3)

plot(-125:126,c_corr(2:253)); axis([-126, 126,-20, 20])

xlabel(' Delay \tau')

ylabel(' Cross-correlation function R_{ji}(\tau)')











