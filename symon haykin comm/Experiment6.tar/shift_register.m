function y = shift_register(x, k)
% Used in Experiment 6: Communications system 4e: Simon Haykin
[m, n] = size(x);

x = x(:);

N = length(x);

k = rem(k, N);

y = zeros(N, 1);

if (k >= 0) 

  y = [x(N-k+1:N); x(1:N-k)];

else

  k = -k;

  y = [x(k+1:N); x(1:k)];

end;

y = reshape(y, m, n);
